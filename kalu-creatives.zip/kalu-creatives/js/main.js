/* ==========================================================================
   KALU CREATIVES — site behaviour
   Reads video data from js/data.js (loaded before this file).
   ========================================================================== */

(function () {
  "use strict";

  const isPlaceholderId = (id) => !id || id.startsWith("REPLACE_WITH_");

  const youtubeThumb = (id) => `https://img.youtube.com/vi/${id}/hqdefault.jpg`;
  const youtubeEmbed = (id) => `https://www.youtube.com/embed/${id}?autoplay=1&rel=0`;

  /* ---------- Portfolio grid ---------- */
  const grid = document.getElementById("portfolioGrid");

  function categoryLabel(cat) {
    return {
      "reels": "Reel",
      "music-videos": "Music Video",
      "documentary": "Documentary",
      "others": "Other"
    }[cat] || cat;
  }

  function buildCard(video) {
    const card = document.createElement("article");
    card.className = "card is-visible";
    card.dataset.category = video.category;

    const placeholder = isPlaceholderId(video.id);

    card.innerHTML = `
      <div class="card__media">
        <div class="video-embed${placeholder ? " is-placeholder" : ""}" data-video-id="${video.id}">
          <img class="video-embed__thumb" alt="${video.title}">
          <button class="video-embed__play" aria-label="Play ${video.title}" ${placeholder ? "tabindex=\"-1\"" : ""}>
            <svg viewBox="0 0 24 24" width="18" height="18"><path d="M8 5v14l11-7z" fill="currentColor"/></svg>
          </button>
        </div>
      </div>
      <div class="card__body">
        <div class="card__meta">
          <span>${categoryLabel(video.category)}</span>
          <span>${video.year || ""}</span>
        </div>
        <h3 class="card__title">${video.title}</h3>
      </div>
    `;

    if (!placeholder) {
      const thumb = card.querySelector(".video-embed__thumb");
      thumb.src = youtubeThumb(video.id);
      const embed = card.querySelector(".video-embed");
      embed.addEventListener("click", () => openLightbox(video.id));
    }

    return card;
  }

  function renderGrid() {
    if (!grid || typeof portfolioVideos === "undefined") return;
    grid.innerHTML = "";
    portfolioVideos.forEach((video) => grid.appendChild(buildCard(video)));
  }

  /* ---------- Filters ---------- */
  function initFilters() {
    const buttons = document.querySelectorAll(".filter");
    buttons.forEach((btn) => {
      btn.addEventListener("click", () => {
        buttons.forEach((b) => {
          b.classList.remove("is-active");
          b.setAttribute("aria-selected", "false");
        });
        btn.classList.add("is-active");
        btn.setAttribute("aria-selected", "true");

        const filter = btn.getAttribute("data-filter");
        document.querySelectorAll(".card").forEach((card) => {
          const match = filter === "all" || card.dataset.category === filter;
          card.classList.toggle("is-visible", match);
        });
      });
    });
  }

  /* ---------- Lightbox ---------- */
  const lightbox = document.getElementById("lightbox");
  const lightboxFrame = document.getElementById("lightboxFrame");

  function openLightbox(id) {
    if (!lightbox || !lightboxFrame) return;
    lightboxFrame.innerHTML = `<iframe src="${youtubeEmbed(id)}" title="Video player" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>`;
    lightbox.classList.add("is-open");
    lightbox.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }

  function closeLightbox() {
    if (!lightbox || !lightboxFrame) return;
    lightbox.classList.remove("is-open");
    lightbox.setAttribute("aria-hidden", "true");
    lightboxFrame.innerHTML = "";
    document.body.style.overflow = "";
  }

  if (lightbox) {
    lightbox.querySelectorAll("[data-close]").forEach((el) => el.addEventListener("click", closeLightbox));
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closeLightbox();
    });
  }

  /* ---------- Mobile nav ---------- */
  const navToggle = document.getElementById("navToggle");
  const navLinks = document.getElementById("navLinks");

  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      const isOpen = navLinks.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
    navLinks.querySelectorAll("a").forEach((a) =>
      a.addEventListener("click", () => {
        navLinks.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      })
    );
  }

  /* ---------- Bottom-bar timecode (decorative, ticks while the page is open) ---------- */
  const timecodeEl = document.getElementById("timecode");
  function startTimecode() {
    if (!timecodeEl) return;
    let frame = 0;
    const fps = 24;
    setInterval(() => {
      frame++;
      const totalSeconds = Math.floor(frame / fps);
      const h = String(Math.floor(totalSeconds / 3600)).padStart(2, "0");
      const m = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, "0");
      const s = String(totalSeconds % 60).padStart(2, "0");
      const f = String(frame % fps).padStart(2, "0");
      timecodeEl.textContent = `${h}:${m}:${s}:${f}`;
    }, 1000 / fps);
  }

  /* ---------- Contact form (mailto fallback — see README to wire up a hosted form) ---------- */
  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const name = contactForm.name.value;
      const email = contactForm.email.value;
      const project = contactForm.project.value;
      const message = contactForm.message.value;

      const subject = encodeURIComponent(`New enquiry — ${project}`);
      const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\nProject type: ${project}\n\n${message}`);
      window.location.href = `mailto:hello@kalucreatives.com?subject=${subject}&body=${body}`;
    });
  }

  /* ---------- Footer year ---------- */
  const yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---------- Init ---------- */
  document.addEventListener("DOMContentLoaded", () => {
    renderGrid();
    initFilters();
    startTimecode();
  });
})();
