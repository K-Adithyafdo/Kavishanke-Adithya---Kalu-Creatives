/**
 * PORTFOLIO VIDEOS
 * -----------------
 * Add one object per video. This is the file you'll come back to most.
 *
 * id       -> the YouTube video ID (the part after "v=" in the URL,
 *             e.g. https://www.youtube.com/watch?v=XXXXXXXXXXX
 *             the ID is XXXXXXXXXXX)
 * title    -> shown under the thumbnail
 * category -> one of: "reels" | "music-videos" | "documentary" | "others"
 * year     -> optional, shown as a small label (e.g. "2025")
 *
 * Until you swap in a real ID, the card shows a dashed placeholder
 * instead of breaking — safe to leave rows in while you're building.
 */

const portfolioVideos = [
  {
    id: "REPLACE_WITH_YOUTUBE_ID_1",
    title: "Project title",
    category: "reels",
    year: "2025"
  },
  {
    id: "REPLACE_WITH_YOUTUBE_ID_2",
    title: "Project title",
    category: "reels",
    year: "2025"
  },
  {
    id: "REPLACE_WITH_YOUTUBE_ID_3",
    title: "Project title",
    category: "music-videos",
    year: "2024"
  },
  {
    id: "REPLACE_WITH_YOUTUBE_ID_4",
    title: "Project title",
    category: "music-videos",
    year: "2024"
  },
  {
    id: "REPLACE_WITH_YOUTUBE_ID_5",
    title: "Project title",
    category: "documentary",
    year: "2024"
  },
  {
    id: "REPLACE_WITH_YOUTUBE_ID_6",
    title: "Project title",
    category: "others",
    year: "2023"
  }
];
